#!/bin/sh
clab deploy --topo frr01.clab.yml
./PC-interfaces.sh
